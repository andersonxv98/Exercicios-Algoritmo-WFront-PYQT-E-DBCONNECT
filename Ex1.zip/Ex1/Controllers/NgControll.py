from Models.Circulo import CirculoCLass
from Models.Retangulo import *
from Models.Retangulo import *

def CalculoRetangulo(wbase, altura):
    print("entrou Calculo REtangulo controller")
    _ret = RetanguloClass(int(wbase), int(altura))
    print(_ret)
    perimetro = _ret.CalculoPerimetro()

    area = _ret.CalculoArea()
    diagonal =_ret.CalculoDiagonal()
    print(perimetro, area, diagonal)
    return perimetro, area, diagonal

def CalculoCirculo(raio):
    print("entrou Calculo REtangulo controller")
    _ret = CirculoCLass(int(raio))
    print(_ret)
    perimetro = _ret.CalculoPerimetro()


    return perimetro
