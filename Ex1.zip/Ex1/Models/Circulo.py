class CirculoCLass:
    def __init__(self, raio):

        self.raio = raio

       # self.area  = self.CalculoArea()
        #self.perimetro = self.CalculoPerimetro()
        #self.diagonal = self.CalculoDiagonal()

    def CalculoPerimetro(self):
        perimetro = 2 * (3.141529) * self.raio
        return perimetro