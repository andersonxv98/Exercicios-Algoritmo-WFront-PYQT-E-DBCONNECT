class RetanguloClass:
    def __init__(self, wbase, altura):

        self.wbase = wbase
        self.altura = altura
       # self.area  = self.CalculoArea()
        #self.perimetro = self.CalculoPerimetro()
        #self.diagonal = self.CalculoDiagonal()

    def CalculoDiagonal(self):
        diagonal = (((self.wbase**2) + (self.altura** 2)) // 2)
        return diagonal

    def CalculoArea(self):
        result = self.wbase * self.altura
        return  result

    def CalculoPerimetro(self):
        perimetro = 2 * (self.wbase + self.altura)
        return perimetro