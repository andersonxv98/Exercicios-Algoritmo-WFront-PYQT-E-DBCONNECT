import sys
from Dependencies.mainDependencies import *
from View.mainView import *

app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()
#Lembrar de Implementarr a Classe DAO -> DB