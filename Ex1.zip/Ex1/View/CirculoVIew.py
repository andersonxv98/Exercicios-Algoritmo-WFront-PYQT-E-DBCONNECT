
from PyQt6.QtWidgets import *

from Controllers.NgControll import  CalculoCirculo


class CirculoViewClass(QMainWindow):
    def __init__(self):
        super().__init__()
        self.lb_r_circulo = QLabel("Raio")
        self.tb_r_circulo = QLineEdit()


        self.lb_perimetro = QLabel("perimetro")


        self.button = QPushButton("Calcular")
        self.button.clicked.connect(self.ChamaController)

        self.layout = QVBoxLayout()

        self.layout.addWidget(self.lb_r_circulo)
        self.layout.addWidget(self.tb_r_circulo)


        self.layout.addWidget(self.button)
        self.layout.addWidget(self.lb_perimetro)


        container = QWidget()
        container.setLayout(self.layout)
        self.setCentralWidget(container)





    def ChamaController(self):
        print("Entrou na função chamacontroller")
        raio = self.tb_r_circulo.text()
        perimetro = CalculoCirculo(raio)
        print("ultimo print: ",perimetro)

        self.lb_perimetro.setText("Perimetro: "+str(perimetro))
        #self.lb_diagonal.setText(diagonal)

