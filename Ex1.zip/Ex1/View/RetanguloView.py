from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *

from Controllers.NgControll import CalculoRetangulo


class RetanguloViewClass(QMainWindow):
    def __init__(self):
        super().__init__()
        self.lb_b_retangulo = QLabel("base")
        self.tb_b_retanqgulo = QLineEdit()
        self.lb_a_retangulo = QLabel("altura")
        self.tb_a_retangulo = QLineEdit()

        self.lb_area = QLabel("area")
        self.lb_perimetro = QLabel("perimetro")
        self.lb_diagonal = QLabel("Diagonal")

        self.button = QPushButton("Calcular")
        self.button.clicked.connect(self.ChamaController)

        self.layout = QVBoxLayout()

        self.layout.addWidget(self.lb_b_retangulo)
        self.layout.addWidget(self.tb_b_retanqgulo)
        self.layout.addWidget(self.lb_a_retangulo)
        self.layout.addWidget(self.tb_a_retangulo)

        self.layout.addWidget(self.button)
        self.layout.addWidget(self.lb_perimetro)
        self.layout.addWidget(self.lb_area)
        self.layout.addWidget(self.lb_diagonal)

        container = QWidget()
        container.setLayout(self.layout)
        self.setCentralWidget(container)





    def ChamaController(self):
        print("Entrou na função chamacontroller")
        val_base = self.tb_b_retanqgulo.text()
        val_Altura = self.tb_a_retangulo.text()
        print(val_base)
        print(val_Altura)
        perimetro, area, diagonal = CalculoRetangulo(val_base, val_Altura)
        print("ultimo print: ",perimetro, area, diagonal)
        self.lb_area.setText("Area: " +str(area))
        self.lb_perimetro.setText("Perimetro: "+str(perimetro))
        self.lb_diagonal.setText("Diagonal: "+str(diagonal))
        #self.lb_diagonal.setText(diagonal)

