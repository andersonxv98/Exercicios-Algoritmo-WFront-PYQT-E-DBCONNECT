
from PyQt6.QtWidgets import QApplication